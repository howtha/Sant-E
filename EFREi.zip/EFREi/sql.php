<?php

$serveur = "localhost";
$data = "EFREI";
$utilisateur = "root";
$mdp = "";

try
  {
  $bdd = new PDO('mysql:host = $serveur; dbname = $data; charset = utf8', $utilisateur, $mdp);
  $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }
  
  catch (Exception $e)
  {
    die('Erreur : ' . $e->getMessage());
  }

?>